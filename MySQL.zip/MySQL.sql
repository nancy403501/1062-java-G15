-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: test
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `action`
--

DROP TABLE IF EXISTS `action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `action` (
  `num` int(11) NOT NULL,
  `subject` varchar(45) DEFAULT NULL,
  `verb` varchar(45) DEFAULT NULL,
  `object` varchar(45) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `tocardnum` int(11) DEFAULT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action`
--

LOCK TABLES `action` WRITE;
/*!40000 ALTER TABLE `action` DISABLE KEYS */;
INSERT INTO `action` VALUES (1,'我','查看','E201','有「門」、「螢幕」',5),(2,'我','查看','門','發現門無法「開啟」',7),(3,'我','查看','螢幕','有題目：你在哪',NULL),(4,'我','移動到','門','門是鎖的',NULL),(5,'E201','開啟','門','門被開啟了，旁邊有「樓梯」',8),(6,'我','移動到','樓梯','我走上樓梯，是工館三樓的「大門」',9),(7,'我','查看','大門','發現門無法「開啟」，但玻璃倒影似乎反射著一道光，那是「廁所」發出的微光',10),(8,'我','移動到','廁所','我人在廁所裡',NULL),(9,'我','查看','廁所','看見「鏡子」及旁邊未封起的「垃圾袋」',11),(10,'我','查看','垃圾袋','發現「破碎的紙張』',13),(11,'我','查看','碎紙','碎紙上有無法解讀的文字，看似少了一半…？',NULL),(12,'碎紙','移動到','鏡子','發現可辨識之文字...有可能是「密碼」',14),(13,'我','移動到','大門','門依舊上鎖著',NULL),(14,'密碼','開啟','大門','恭喜你成功逃出工館，不要忘記下下禮拜期末考哦！G15祝考試順利<3',NULL),(15,'我','開啟','大門','門鎖著',NULL),(16,'我','移動到','E201','你在E201',NULL),(17,'我','開啟','門','門是鎖的，不是你開啟門',NULL),(18,'我','查看','鏡子','鏡子倒映著我的臉...',NULL),(19,'我','查看','樓梯','似乎可以走上三樓',NULL),(20,'碎紙','開啟','大門','你還沒得到密碼喔',NULL);
/*!40000 ALTER TABLE `action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cards`
--

DROP TABLE IF EXISTS `cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `cards` (
  `cardnum` int(11) NOT NULL,
  `card` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `buttonName` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`cardnum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cards`
--

LOCK TABLES `cards` WRITE;
/*!40000 ALTER TABLE `cards` DISABLE KEYS */;
INSERT INTO `cards` VALUES (1,'我','SubjectObject','me'),(2,'查看','Verb','search'),(3,'移動到','Verb','move'),(4,'E201','SubjectObject','E201'),(5,'門','SubjectObject','door'),(6,'螢幕','SubjectObject','screen'),(7,'開啟','Verb','open'),(8,'樓梯','SubjectObject','stair'),(9,'大門','SubjectObject','bigdoor'),(10,'廁所','SubjectObject','wc'),(11,'鏡子','SubjectObject','mirror'),(12,'垃圾袋','SubjectObject','gbbg'),(13,'碎紙','SubjectObject','paper'),(14,'密碼','SubjectObject','pswd');
/*!40000 ALTER TABLE `cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'test'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-21 14:32:04

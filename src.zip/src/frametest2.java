
public class frametest2 {

	public static void main(String[] args) {
		gameUI f = new gameUI();
		f.setTitle("Escape");
		f.setSize(800,650);
		f.setVisible(true);
		f.setLocationRelativeTo(null);
	}
}


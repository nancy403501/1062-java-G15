
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class GameUI extends JPanel implements ActionListener {
	int MaxCardNumber = 100;
	String[] card = new String[MaxCardNumber];
	String[] cardType = new String[MaxCardNumber];
	String[] buttonName = new String[MaxCardNumber];
	int cardNumber = 0;

	Icon exitpic,stpic,paperq,papera,E201pic,qpic,toipic,mipic,epic,bigdpic;
	JPanel southct;
	JButton[] button = new JButton[MaxCardNumber];
	JButton E201, me, door, bigdoor,screen, stair, wc, mirror, pswd, paper, gbbg;
	JButton search, move, open, upto;
	JTextArea text, bttext;
	JTextField subject, verb, object;
	JLabel plus, plus2,exitlb,stlb,paqlb,paalb,e201lb,qlb,toilb,milb,elb,bigdlb;
	JOptionPane op;
	
	public GameUI() {
		
		this.setLayout(new BorderLayout());
		southct = new JPanel();
		
		stpic = new ImageIcon(getClass().getResource("st.jpg"));
		stlb = new JLabel(stpic);
		stlb.setBounds(10, 20, 640, 360);
		southct.add(stlb);
		stlb.setVisible(false);
		
		paperq = new ImageIcon(getClass().getResource("paperq.png"));
		paqlb = new JLabel(paperq);
		paqlb.setBounds(10, 20, 640, 360);
		southct.add(paqlb);
		paqlb.setVisible(false);
		
		papera = new ImageIcon(getClass().getResource("papera.png"));
		paalb = new JLabel(papera);
		paalb.setBounds(10, 20, 640, 360);
		southct.add(paalb);
		paalb.setVisible(false);
		
		exitpic = new ImageIcon(getClass().getResource("exit.png"));
		exitlb = new JLabel(exitpic);
		exitlb.setBounds(10, 20, 640, 360);
		southct.add(exitlb);
		exitlb.setVisible(false);
		
		E201pic = new ImageIcon(getClass().getResource("E201pi.jpg"));
		e201lb = new JLabel(E201pic);
		e201lb.setBounds(10, 20, 640, 360);
		southct.add(e201lb);
		
		qpic = new ImageIcon(getClass().getResource("q.jpg"));
		qlb = new JLabel(qpic);
		qlb.setBounds(10, 20, 640, 360);
		southct.add(qlb);
		qlb.setVisible(false);
		
		toipic = new ImageIcon(getClass().getResource("toilet.jpg"));
		toilb = new JLabel(toipic);
		toilb.setBounds(10, 20, 640, 360);
		southct.add(toilb);
		toilb.setVisible(false);
		
		mipic = new ImageIcon(getClass().getResource("mipic.jpg"));
		milb = new JLabel(mipic);
		milb.setBounds(150, 5,350 , 399);
		southct.add(milb);
		milb.setVisible(false);
		
		epic = new ImageIcon(getClass().getResource("E.jpg"));
		elb = new JLabel(epic);
		elb.setBounds(10, 20, 640, 360);
		southct.add(elb);
		elb.setVisible(false);
		
		bigdpic = new ImageIcon(getClass().getResource("bigdoor.jpg"));
		bigdlb = new JLabel(bigdpic);
		bigdlb.setBounds(10, 20, 640, 360);
		southct.add(bigdlb);
		bigdlb.setVisible(false);
		
		text = new JTextArea(3, 4);
		text.setBounds(160, 490, 400, 110);
		text.setEditable(false);
		text.setFont(new Font("細明體", Font.PLAIN, 25));
		text.setText("「我」醒來時，發現教室誰都不在了…我趕緊「查看」，這裡應該是上一節課「移動到」的「E201」");
		text.setLineWrap(true);
		southct.add(text);

		subject = new JTextField();
		subject.setBounds(160, 430, 80, 40);
		subject.setEditable(false);
		subject.setFont(new Font("細明體", Font.PLAIN, 25));
		southct.add(subject);

		plus = new JLabel("+");
		plus.setBounds(260, 430, 80, 40);
		southct.add(plus);

		verb = new JTextField();
		verb.setBounds(290, 430, 80, 40);
		verb.setEditable(false);
		verb.setFont(new Font("細明體", Font.PLAIN, 25));
		southct.add(verb);

		plus2 = new JLabel("+");
		plus2.setBounds(390, 430, 80, 40);
		southct.add(plus2);

		object = new JTextField();
		object.setBounds(420, 430, 80, 40);
		object.setEditable(false);
		object.setFont(new Font("細明體", Font.PLAIN, 25));
		southct.add(object);
		southct.setLayout(null);
		add(southct);

		JPanel anspanel = new JPanel();

		JScrollPane scroll = new JScrollPane(anspanel, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scroll.setPreferredSize(new Dimension(120, 100));

		anspanel.setLayout(new BoxLayout(anspanel, BoxLayout.Y_AXIS));

		// �q��Ʈw������r�d
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		} catch (Exception ex) {
			// handle the error
		}

		Connection conn = null;  
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost/test?"
					+ "user=root&password=yosafire520&serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true");

			Statement stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery("select c.cardnum, card, type, buttonName" + " from cards c");

			while (rs.next()) {
				card[cardNumber] = rs.getString(2);
				cardType[cardNumber] = rs.getString(3);
				buttonName[cardNumber] = rs.getString(4);
				cardNumber++;
			}

		} catch (SQLException ex) {
			// handle any errors
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}

		cardNumber = 0;
		anspanel.add(Box.createVerticalStrut(13));
		for (int i = 0; i < MaxCardNumber; i++) {
			button[i] = new JButton(card[i]);
		}		
		
////////�w�]
		me = button[cardNumber++];
		me.setFont(new Font("細明體", Font.BOLD, 20));
		me.setBackground(new Color(135, 206, 250));
		me.addActionListener(this);
		anspanel.add(me);
		anspanel.add(Box.createVerticalStrut(15));
		
		search = button[cardNumber++];
		search.setFont(new Font("細明體", Font.BOLD, 20));
		search.setBackground(new Color(240, 128, 128));
		search.addActionListener(this);
		anspanel.add(search);
		anspanel.add(Box.createVerticalStrut(15));

		move = button[cardNumber++];
		move.setFont(new Font("細明體", Font.BOLD, 20));
		move.setBackground(new Color(240, 128, 128));
		move.addActionListener(this);
		anspanel.add(move);
		anspanel.add(Box.createVerticalStrut(15));

		E201 = button[cardNumber++];
		E201.setFont(new Font("細明體", Font.BOLD, 20));
		E201.setBackground(new Color(135, 206, 250));
		E201.addActionListener(this);
		anspanel.add(E201);
		E201.setEnabled(true);
		E201.setVisible(true);
		anspanel.add(Box.createVerticalStrut(15));
////////�w�]
		
		door = button[cardNumber++];
		door.setFont(new Font("細明體", Font.BOLD, 20));
		door.setBackground(new Color(135, 206, 250));
		door.addActionListener(this);
		anspanel.add(door);
		door.setEnabled(false);
		door.setVisible(false);
		anspanel.add(Box.createVerticalStrut(15));
		

		screen = button[cardNumber++];
		screen.setFont(new Font("細明體", Font.BOLD, 20));
		screen.setBackground(new Color(135, 206, 250));
		screen.addActionListener(this);
		anspanel.add(screen);
		screen.setEnabled(false);
		screen.setVisible(false);
		anspanel.add(Box.createVerticalStrut(15));
		
		open = button[cardNumber++];
		open.setFont(new Font("細明體", Font.BOLD, 20));
		open.setBackground(new Color(240, 128, 128));
		open.addActionListener(this);
		anspanel.add(open);
		open.setEnabled(false);
		open.setVisible(false);
		anspanel.add(Box.createVerticalStrut(15));

		stair = button[cardNumber++];
		stair.setBackground(new Color(135, 206, 250));
		stair.setFont(new Font("細明體", Font.BOLD, 20));
		stair.addActionListener(this);
		anspanel.add(stair);
		stair.setEnabled(false);
		stair.setVisible(false);
		anspanel.add(Box.createVerticalStrut(15));
		
		bigdoor = button[cardNumber++];
		bigdoor.setFont(new Font("細明體", Font.BOLD, 20));
		bigdoor.setBackground(new Color(135, 206, 250));
		bigdoor.addActionListener(this);
		anspanel.add(bigdoor);
		bigdoor.setEnabled(false);
		bigdoor.setVisible(false);
		anspanel.add(Box.createVerticalStrut(15));

		wc = button[cardNumber++];
		wc.setFont(new Font("細明體", Font.BOLD, 20));
		wc.setBackground(new Color(135, 206, 250));
		wc.addActionListener(this);
		anspanel.add(wc);
		wc.setEnabled(false);
		wc.setVisible(false);
		anspanel.add(Box.createVerticalStrut(15));

		mirror = button[cardNumber++];
		mirror.setFont(new Font("細明體", Font.BOLD, 20));
		mirror.setBackground(new Color(135, 206, 250));
		mirror.addActionListener(this);
		anspanel.add(mirror);
		mirror.setEnabled(false);
		mirror.setVisible(false);
		anspanel.add(Box.createVerticalStrut(15));
		
		gbbg = button[cardNumber++];
		gbbg.setFont(new Font("細明體", Font.BOLD, 20));
		gbbg.setBackground(new Color(135, 206, 250));
		gbbg.addActionListener(this);
		anspanel.add(gbbg);
		gbbg.setEnabled(false);
		gbbg.setVisible(false);
		anspanel.add(Box.createVerticalStrut(15));
		
		paper = button[cardNumber++];
		paper.setFont(new Font("細明體", Font.BOLD, 20));
		paper.setBackground(new Color(135, 206, 250));
		paper.addActionListener(this);
		anspanel.add(paper);
		paper.setEnabled(false);
		paper.setVisible(false);
		anspanel.add(Box.createVerticalStrut(15));

		pswd = button[cardNumber++];
		pswd.setFont(new Font("細明體", Font.BOLD, 20));
		pswd.setBackground(new Color(135, 206, 250));
		pswd.addActionListener(this);
		anspanel.add(pswd);
		pswd.setEnabled(false);
		pswd.setVisible(false);
		anspanel.add(Box.createVerticalStrut(15));

		add(scroll, BorderLayout.EAST);

	}

	CatchExpressionDemo express = new CatchExpressionDemo();
	String expression = null;
	private boolean isSubjectEmpty = true, isObjectEmpty = true;

	@Override
	public void actionPerformed(ActionEvent ate) {
		int i;
		String tmpCardType = null;

		for (i = 0; i < cardNumber; i++) {
			if (ate.getSource() == button[i]) {
				tmpCardType = cardType[i];
				break;
			}
		}
		if (tmpCardType.equals("SubjectObject")) {
			// if (tmpCardType == cardType[i]) {
			if (isSubjectEmpty == true) {
				Sound.play("src/resources/click.wav");
				subject.setText(card[i]);
				isSubjectEmpty = false;
			} else if (isObjectEmpty == true) {
				Sound.play("src/resources/click.wav");
				object.setText(card[i]);
				isObjectEmpty = false;
			} else {
				Sound.play("src/resources/click.wav");
				subject.setText(card[i]);
				verb.setText(null);
				object.setText(null);
				isSubjectEmpty = false;
				isObjectEmpty = true;
			}			
		express.getSubOrOb(card[i]);
		}
		else {
			Sound.play("src/resources/click.wav");
			verb.setText(card[i]);
 			express.getVerb(card[i]);
		}	
		
		int storyLine = 0;
		

		expression = express.getExpression();
		storyLine = express.getStoryLineNum();
		text.setText(expression);
		text.setLineWrap(true);
		switch(storyLine) {
			case 1: 
				door.setVisible(true);
				door.setEnabled(true);
				screen.setVisible(true);
				screen.setEnabled(true);
				break;
			case 2:
				e201lb.setVisible(false);
				open.setVisible(true);
				open.setEnabled(true);
				break;
			case 3:
				e201lb.setVisible(false);
				//qlb.setVisible(true);
				break;
			case 4:
				e201lb.setVisible(false);
				//qlb.setVisible(false);
				break;
			case 5:
				//qlb.setVisible(false);
				stair.setVisible(true);
				stair.setEnabled(true);
				E201.setEnabled(false);
				E201.setVisible(false);
				door.setVisible(false);
				door.setEnabled(false);
				screen.setVisible(false);
				screen.setEnabled(false);
				break;
			case 6:
				e201lb.setVisible(false);
				//elb.setVisible(true);
				bigdoor.setVisible(true);
				bigdoor.setEnabled(true);
				break;
			case 7:
				wc.setVisible(true);
				wc.setEnabled(true);
				stair.setVisible(false);
				stair.setEnabled(false);
				//elb.setVisible(false);
				//bigdlb.setVisible(true);
				break;
			case 8:
				//toilb.setVisible(true);
				//bigdlb.setVisible(false);
				break;
			case 9:
				mirror.setVisible(true);
				mirror.setEnabled(true);
				gbbg.setVisible(true);
				gbbg.setEnabled(true);
				//toilb.setVisible(true);
				break;
			case 10:
				//milb.setVisible(false);
				//toilb.setVisible(false);
				//paqlb.setVisible(true);
				paper.setVisible(true);
				paper.setEnabled(true);
				break;
			case 11:
				//milb.setVisible(false);
				break;
			case 12:
				//paqlb.setVisible(false);
				//paalb.setVisible(true);
				bigdoor.setVisible(true);
				bigdoor.setEnabled(true);
				break;
			case 13:
				stair.setVisible(false);
				stair.setEnabled(false);
				mirror.setVisible(false);
				mirror.setEnabled(false);
				gbbg.setVisible(false);
				gbbg.setEnabled(false);
				paper.setVisible(false);
				paper.setEnabled(false);
				//bigdlb.setVisible(true);
				break;
			case 14:
				//paalb.setVisible(false);
				exitlb.setVisible(true);
				stair.setVisible(false);
				stair.setEnabled(false);
				//bigdlb.setVisible(false);
				break;
			case 15:
				stair.setVisible(false);
				stair.setEnabled(false);
				mirror.setVisible(false);
				mirror.setEnabled(false);
				gbbg.setVisible(false);
				gbbg.setEnabled(false);
				break;
			case 18:
				//toilb.setVisible(false);
				//milb.setVisible(true);
			default:
				break;
			
		}
		
		if(subject.getText().equals("E201")&&verb.getText().equals("開啟")&&object.getText().equals("門")) {
			Sound.play("src/resources/opendoor.wav");
			stlb.setVisible(true);
		}
		else {
			stlb.setVisible(false);
		}
		if(subject.getText().equals("我")&&verb.getText().equals("移動到")&&object.getText().equals("樓梯")) {
			Sound.play("src/resources/step.wav");
			elb.setVisible(true);
		}
		else {
			elb.setVisible(false);
		}
		if(subject.getText().equals("碎紙")&&verb.getText().equals("移動到")&&object.getText().equals("鏡子")) {
			paalb.setVisible(true);
			String input=JOptionPane.showInputDialog("請輸入密碼(密碼提示：16H)");
			if(input.equals("CSIE") || input.equals("csie")) {
				JOptionPane.showMessageDialog(southct,"密碼正確");
				pswd.setEnabled(true);
				pswd.setVisible(true);
			}
			else 
				JOptionPane.showMessageDialog(southct, "密碼錯誤，請從新放回字卡再次嘗試");
		}
		else {
			paalb.setVisible(false);
		}
		if(subject.getText().equals("我")&&verb.getText().equals("查看")&&object.getText().equals("螢幕")) 
			qlb.setVisible(true);
		else {
			qlb.setVisible(false);
		}
		if(subject.getText().equals("我")&&verb.getText().equals("查看")&&object.getText().equals("大門")) 
			bigdlb.setVisible(true);
		else {
			bigdlb.setVisible(false);
		}
		if((subject.getText().equals("我")&&verb.getText().equals("查看")&&object.getText().equals("垃圾袋"))||(subject.getText().equals("我")&&verb.getText().equals("查看")&&object.getText().equals("碎紙"))) 
			paqlb.setVisible(true);
		else {
			paqlb.setVisible(false);
		}
		if((subject.getText().equals("我")&&verb.getText().equals("查看")&&object.getText().equals("廁所"))||(subject.getText().equals("我")&&verb.getText().equals("移動到")&&object.getText().equals("廁所"))) 
			toilb.setVisible(true);
		else {
			toilb.setVisible(false);
		}
		if(subject.getText().equals("我")&&verb.getText().equals("查看")&&object.getText().equals("鏡子")) 
			milb.setVisible(true);
		else {
			milb.setVisible(false);
		}
		if(subject.getText().equals("密碼")&&verb.getText().equals("開啟")&&object.getText().equals("大門")) 
			Sound.play("src/resources/goal.wav");
				
	}
}

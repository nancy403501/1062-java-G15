
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
//���ɴ���
import java.io.FileNotFoundException;

import java.io.File;
import java.io.FileInputStream;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class GameMenu implements ActionListener{
	JButton Start,Quit;
	JPanel menu,test;
	JFrame f;
	GameUI ui;
	JLabel eclabel;
	
	public GameMenu() {	
		Start = new JButton("start");
		Quit = new JButton("quit");
		menu = new JPanel();
		
		ui = new GameUI();

		menu.setLayout(null);
		Start.setBounds(340, 300, 100, 50);
		Quit.setBounds(340, 430, 100, 50);
		
		Start.addActionListener(this);
		Quit.addActionListener(this);
		
		Icon ec = new ImageIcon(getClass().getResource("bgmix.jpg"));
		eclabel = new JLabel(ec);
		eclabel.setBounds(0, 0, 800, 650);
		
		menu.add(Start);
		menu.add(Quit);
		
		f = new JFrame("Escape");
		f.setSize(800, 650);
		f.setLocationRelativeTo(null);
		f.setVisible(true);
		f.add(eclabel);
		f.add(menu);		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==Start) {
			f.remove(menu);//remove the current panel being displayed
			f.remove(eclabel);
			f.add(ui);//add the panel that you want to display next
			f.validate();//this is needed to make the change work
			f.repaint();//this will force the frame to display the new panel		
		}
		if(e.getSource()==Quit) {
			System.exit(0);
		}
	}	
	public static void main (String[] args) {
		new GameMenu();
        Sound.play("src/resources/horror.wav");
	}

}
